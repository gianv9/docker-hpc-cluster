## docker.openmpi Fork, Only OpenMPI with C/C++

All credit goes to dispel4py/docker.openmpi
