#!/bin/bash

docker stack rm Test
