# MPI-Splitter

> Split, encrypt, decrypt & concatenate
> files with MPI in Linux-based HPC Clusters
